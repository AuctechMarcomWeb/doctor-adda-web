import React from "react";
import DoctorAddaLanding from "../components/DoctorAddaLanding";

const Home = () => {
  return (
    <>
      <DoctorAddaLanding />
    </>
  );
};

export default Home;
